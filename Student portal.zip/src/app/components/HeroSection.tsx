import imgHeroImage from "figma:asset/dafb87b5fa06b9ee5f6a35823ca40c2d66807caf.png";

interface HeroSectionProps {
  onJoinNow: () => void;
  onLoginDashboard: () => void;
}

export function HeroSection({ onJoinNow, onLoginDashboard }: HeroSectionProps) {
  return (
    <section
      id="home"
      className="relative min-h-[auto] sm:min-h-[600px] lg:min-h-[720px] bg-[#fefefe] overflow-hidden pt-[70px] sm:pt-[80px]"
    >
      {/* Text Content */}
      <div className="relative z-10 max-w-[1440px] mx-auto px-5 sm:px-10 lg:px-[69px] pt-[40px] sm:pt-[80px] lg:pt-[120px]">
        <div className="max-w-full sm:max-w-[560px]">
          <h1 className="font-['Asgard_Trial',serif] text-black leading-[91.8%] mb-[10px] text-[56px] sm:text-[80px] md:text-[100px] lg:text-[115px]">
            Student Portal
          </h1>
          <p className="font-['Kenac',sans-serif] text-black opacity-80 leading-normal max-w-[520px] text-[16px] sm:text-[20px] md:text-[22px] lg:text-[24px]">
            Aviation and Aerospace University Bangladesh
          </p>

          <div className="flex flex-wrap gap-3 sm:gap-6 mt-[20px] sm:mt-[36px]">
            <button
              onClick={onJoinNow}
              className="bg-[#4b68e6] text-white font-['Inter',sans-serif] font-medium text-[14px] sm:text-[18px] px-4 sm:px-5 py-2 sm:py-3.5 rounded-[10px] cursor-pointer hover:bg-[#3a57d5] transition-colors"
            >
              Join Now
            </button>
            <button
              onClick={onLoginDashboard}
              className="bg-[rgba(224,207,252,0.65)] text-black font-['Inter',sans-serif] font-medium text-[14px] sm:text-[18px] px-4 sm:px-6 py-2 sm:py-3.5 rounded-[10px] border border-[rgba(46,46,46,0.2)] cursor-pointer hover:bg-[rgba(224,207,252,0.85)] transition-colors"
            >
              Login to Dashboard
            </button>
          </div>
        </div>
      </div>

      {/* Hero Image */}
      <div className="relative sm:absolute mt-6 sm:mt-0 sm:top-[110px] lg:top-[145px] right-0 sm:right-[20px] w-full sm:w-[48%] lg:w-[580px] h-[250px] sm:h-[320px] lg:h-[460px]">
        <div className="absolute inset-0 overflow-hidden">
          <img
            alt="Hero illustration"
            className="absolute h-[117.46%] left-[-10%] sm:left-[-27.28%] max-w-none top-[-5.59%] w-[120%] sm:w-[146%]"
            src={imgHeroImage}
          />
        </div>
      </div>
    </section>
  );
}